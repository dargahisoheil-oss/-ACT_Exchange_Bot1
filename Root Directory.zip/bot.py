import requests
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes

TOKEN = "توکن_ربات_تو"

# دریافت نرخ ارز
def get_rate(from_currency, to_currency):
    url = f"https://api.exchangerate.host/convert?from={from_currency}&to={to_currency}"
    data = requests.get(url).json()
    return data["result"]

# شروع ربات
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = """
سلام 👋
به ربات تبادل ارز خوش اومدی

فرمت تبدیل:
USD EUR 100
یعنی:
100 دلار به یورو
"""
    await update.message.reply_text(text)

# تبدیل ارز
async def convert(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        msg = update.message.text.split()
        from_cur = msg[0].upper()
        to_cur = msg[1].upper()
        amount = float(msg[2])

        rate = get_rate(from_cur, to_cur)
        result = rate * amount

        await update.message.reply_text(
            f"{amount} {from_cur} = {round(result,2)} {to_cur}"
        )

    except:
        await update.message.reply_text("فرمت اشتباهه ❌\nمثال:\nUSD EUR 100")

# اجرا
app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, convert))
app.run_polling()